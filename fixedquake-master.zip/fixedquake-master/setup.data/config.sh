#
# Use this script to customize the installer bootstrap script
#

# override some defaults

# try to get root prior to running setup?
# 0: no
# 1: prompt, but run anyway if fails
# 2: require, abort if root fails
#GET_ROOT=1

FATAL_ERROR="Please contact Id Software at <ttimo@idsoftware.com>"

#XSU_ICON="-i icon.xpm"

