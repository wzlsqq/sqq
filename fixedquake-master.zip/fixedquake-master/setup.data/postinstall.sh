#!/bin/sh

# hack around some makeself bugs
chmod +x $SETUP_INSTALLPATH/code/unix/cons
chmod +x $SETUP_INSTALLPATH/code/unix/pcons-2.3.1
