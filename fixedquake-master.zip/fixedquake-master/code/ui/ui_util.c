// ui_util.c
//
// origin: rad
// new ui support stuff
// 
// memory, string alloc


